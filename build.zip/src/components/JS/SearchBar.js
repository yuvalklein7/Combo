import { useState } from 'react';
import TextField from '@mui/material/TextField';
import Autocomplete from '@mui/material/Autocomplete';
import SearchIcon from '@mui/icons-material/Search';
import IconButton from '@mui/material/IconButton';
import '../CSS/SearchBar.css'
import { Fragment } from 'react';
import TuneIcon from '@mui/icons-material/Tune';
import Popper from '@mui/material/Popper';
import PopperContent from './PopperContent';

export default function SearchBar(props) {
    const [anchorEl, setAnchorEl] = useState(null);
    const [open, setOpen] = useState(false);
    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
        setOpen(!open);
    };
    const [years, setYears] = useState([2000, 2030])
    // const [years,setYears]=useState([])

    const cancer_types = [
        "Acute Lymphoblastic Leukemia (ALL)",
        "Acute Myeloid Leukemia (AML)",
        "Adolescents, Cancer in",
        "Adrenocortical Carcinoma",
        "AIDS-Related Cancers",
        "Kaposi Sarcoma (Soft Tissue Sarcoma)",
        "AIDS-Related Lymphoma (Lymphoma)",
        "Primary CNS Lymphoma (Lymphoma)",
        "Anal Cancer",
        "Appendix Cancer - see Gastrointestinal Carcinoid Tumors",
        "Astrocytomas, Childhood (Brain Cancer)",
        "Atypical Teratoid/Rhabdoid Tumor, Childhood, Central Nervous System (Brain Cancer)",
        "Basal Cell Carcinoma of the Skin - see Skin Cancer",
        "Bile Duct Cancer",
        "Bladder Cancer",
        "Bone Cancer (includes Ewing Sarcoma and Osteosarcoma and Malignant Fibrous Histiocytoma)",
        "Brain Tumors",
        "Breast Cancer",
        "Bronchial Tumors (Lung Cancer)",
        "Burkitt Lymphoma - see Non-Hodgkin Lymphoma",
        "Carcinoid Tumor (Gastrointestinal)",
        "Carcinoma of Unknown Primary",
        "Central Nervous System",
        "Atypical Teratoid/Rhabdoid Tumor, Childhood (Brain Cancer)",
        "Medulloblastoma and Other CNS Embryonal Tumors, Childhood (Brain Cancer)",
        "Germ Cell Tumor, Childhood (Brain Cancer)",
        "Primary CNS Lymphoma",
        "Cervical Cancer",
        "Childhood Cancers",
        "Childhood Cardiac Tumors Treatment",
        "Cancers of Childhood, Rare",
        "Cholangiocarcinoma - see Bile Duct Cancer",
        "Chordoma, Childhood (Bone Cancer)",
        "Chronic Lymphocytic Leukemia (CLL)",
        "Chronic Myelogenous Leukemia (CML)",
        "Chronic Myeloproliferative Neoplasms",
        "Colorectal Cancer",
        "Craniopharyngioma, Childhood (Brain Cancer)",
        "Cutaneous T-Cell Lymphoma - see Lymphoma (Mycosis Fungoides and Sézary Syndrome)",
        "Ductal Carcinoma In Situ (DCIS) - see Breast Cancer",
        "Embryonal Tumors, Medulloblastoma and Other Central Nervous System, Childhood (Brain Cancer)",
        "Endometrial Cancer (Uterine Cancer)",
        "Ependymoma, Childhood (Brain Cancer)",
        "Esophageal Cancer",
        "Esthesioneuroblastoma (Head and Neck Cancer)",
        "Ewing Sarcoma (Bone Cancer)",
        "Extracranial Germ Cell Tumor, Childhood",
        "Extragonadal Germ Cell Tumor",
        "Eye Cancer",
        "Intraocular Melanoma",
        "Retinoblastoma",
        "Fallopian Tube Cancer",
        "Gallbladder Cancer",
        "Gastric (Stomach) Cancer",
        "Gastrointestinal Carcinoid Tumor",
        "Gastrointestinal Stromal Tumors (GIST) (Soft Tissue Sarcoma)",
        "Germ Cell Tumors",
        "Childhood Central Nervous System Germ Cell Tumors (Brain Cancer)",
        "Childhood Extracranial Germ Cell Tumors",
        "Extragonadal Germ Cell Tumors",
        "Ovarian Germ Cell Tumors",
        "Testicular Cancer",
        "Gestational Trophoblastic Disease",
        "Hairy Cell Leukemia",
        "Head and Neck Cancer",
        "Heart Tumors, Childhood",
        "Hepatocellular (Liver) Cancer",
        "Histiocytosis, Langerhans Cell",
        "Hodgkin Lymphoma",
        "Hypopharyngeal Cancer (Head and Neck Cancer)",
        "Islet Cell Tumors, Pancreatic Neuroendocrine Tumors",
        "Kidney (Renal Cell) Cancer",
        "Langerhans Cell Histiocytosis",
        "Laryngeal Cancer (Head and Neck Cancer)",
        "Leukemia",
        "Lip and Oral Cavity Cancer (Head and Neck Cancer)",
        "Liver Cancer",
        "Lung Cancer (Non-Small Cell, Small Cell, Pleuropulmonary Blastoma, Pulmonary Inflammatory Myofibroblastic Tumor, and Tracheobronchial Tumor)",
        "Lymphoma",
        "Male Breast Cancer",
        "Melanoma",
        "Melanoma, Intraocular (Eye)",
        "Merkel Cell Carcinoma (Skin Cancer)",
        "Mesothelioma, Malignant",
        "Metastatic Cancer",
        "Metastatic Squamous Neck Cancer with Occult Primary (Head and Neck Cancer)",
        "Midline Tract Carcinoma With NUT Gene Changes",
        "Mouth Cancer (Head and Neck Cancer)",
        "Multiple Endocrine Neoplasia Syndromes",
        "Multiple Myeloma/Plasma Cell Neoplasms",
        "Mycosis Fungoides (Lymphoma)",
        "Myelodysplastic Syndromes, Myelodysplastic/Myeloproliferative Neoplasms",
        "Myelogenous Leukemia, Chronic (CML)",
        "Myeloid Leukemia, Acute (AML)",
        "Myeloproliferative Neoplasms, Chronic",
        "Nasal Cavity and Paranasal Sinus Cancer (Head and Neck Cancer)",
        "Nasopharyngeal Cancer (Head and Neck Cancer)",
        "Neuroblastoma",
        "Non-Hodgkin Lymphoma",
        "Non-Small Cell Lung Cancer",
        "Oral Cancer, Lip and Oral Cavity Cancer and Oropharyngeal Cancer (Head and Neck Cancer)",
        "Osteosarcoma and Undifferentiated Pleomorphic Sarcoma of Bone Treatment",
        "Ovarian Cancer",
        "Pancreatic Cancer",
        "Pancreatic Neuroendocrine Tumors (Islet Cell Tumors)",
        "Papillomatosis (Childhood Laryngeal)",
        "Paraganglioma",
        "Paranasal Sinus and Nasal Cavity Cancer (Head and Neck Cancer)",
        "Parathyroid Cancer",
        "Penile Cancer",
        "Pharyngeal Cancer (Head and Neck Cancer)",
        "Pheochromocytoma",
        "Pituitary Tumor",
        "Plasma Cell Neoplasm/Multiple Myeloma",
        "Pleuropulmonary Blastoma (Lung Cancer)",
        "Pregnancy and Breast Cancer",
        "Primary Central Nervous System (CNS) Lymphoma",
        "Primary Peritoneal Cancer",
        "Prostate Cancer",
        "Pulmonary Inflammatory Myofibroblastic Tumor (Lung Cancer)",
        "Rare Cancers of Childhood",
        "Rectal Cancer",
        "Recurrent Cancer",
        "Renal Cell (Kidney) Cancer",
        "Rhabdomyosarcoma, Childhood (Soft Tissue Sarcoma)",
        "Salivary Gland Cancer (Head and Neck Cancer)",
        "Sarcoma",
        "Childhood Rhabdomyosarcoma (Soft Tissue Sarcoma)",
        "Childhood Vascular Tumors (Soft Tissue Sarcoma)",
        "Osteosarcoma (Bone Cancer)",
        "Soft Tissue Sarcoma",
        "Uterine Sarcoma",
        "Sézary Syndrome (Lymphoma)",
        "Skin Cancer",
        "Small Cell Lung Cancer",
        "Small Intestine Cancer",
        "Squamous Cell Carcinoma of the Skin - see Skin Cancer",
        "Squamous Neck Cancer with Occult Primary, Metastatic (Head and Neck Cancer)",
        "Stomach (Gastric) Cancer",
        "T-Cell Lymphoma, Cutaneous - see Lymphoma (Mycosis Fungoides and Sèzary Syndrome)",
        "Throat Cancer (Head and Neck Cancer)",
        "Nasopharyngeal Cancer",
        "Oropharyngeal Cancer",
        "Hypopharyngeal Cancer",
        "Thymoma and Thymic Carcinoma",
        "Thyroid Cancer",
        "Tracheobronchial Tumors (Lung Cancer)",
        "Transitional Cell Cancer of the Renal Pelvis and Ureter (Kidney (Renal Cell) Cancer)",
        "Unknown Primary, Carcinoma of",
        "Ureter and Renal Pelvis, Transitional Cell Cancer (Kidney (Renal Cell) Cancer",
        "Urethral Cancer",
        "Uterine Cancer, Endometrial",
        "Vaginal Cancer",
        "Vascular Tumors (Soft Tissue Sarcoma)",
        "Vulvar Cancer",
        "Wilms Tumor and Other Childhood Kidney Tumors",
    ];

    const handleChange = (e) => {
        if (e.type === 'click')
            props.setValue(e.target.innerHTML)
        else
            props.setValue(e.target.value)
    }
    return (
        <Fragment>
            <Autocomplete
                renderInput={(params) => <TextField {...params} label="Type Cancer" />}
                freeSolo
                options={cancer_types}
                onInputChange={(e) => { handleChange(e) }}
                disableClearable
            />
            <IconButton className='search-icon' onClick={() => { props.goToSearch(props.value,years) }} >
                <SearchIcon size='medium' />
            </IconButton>
            <IconButton onClick={handleClick}>
                <TuneIcon className='filter-icon' size='medium' />
            </IconButton>
            <Popper sx={{zIndex: '1'}} open={open} anchorEl={anchorEl} placement='top' >
                <PopperContent value={years} setValue={setYears}/>
            </Popper>
        </Fragment>
    )
}