import { Typography } from "@mui/material";

export default function About(props){
    return (
        <Typography variant="h1" className="blah">
            About
        </Typography>
    )
}